﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vygolov1
{
    class Class1
    {
        public static int cl1 = 0, cl2 = 0, cl3 = 0, fcl = 0;
        
    }
}
